from django.shortcuts import render


def home(request):
    return render(request, "mymember/login.html")
    # return render(request, "index.html") -> 불필요한 파일 삭제