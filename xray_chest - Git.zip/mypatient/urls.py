from django.urls import path
from mypatient import views

urlpatterns = [
    path('', views.home),
    path('regi', views.regi),
    path('detail', views.detail),
    path('update', views.update),
    path('delete', views.delete),
    path('search', views.search),
]