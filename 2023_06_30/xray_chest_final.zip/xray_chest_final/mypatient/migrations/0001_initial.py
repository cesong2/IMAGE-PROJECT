from django.db import migrations

class Migration(migrations.Migration):
    dependencies = [
        # 이 마이그레이션이 의존하는 다른 마이그레이션 파일들을 나열합니다.
        # 예: ('otherapp', '0001_initial'),
    ]

    operations = [
        # 마이그레이션 작업들을 나열합니다.
        # 예: migrations.CreateModel(...),
    ]